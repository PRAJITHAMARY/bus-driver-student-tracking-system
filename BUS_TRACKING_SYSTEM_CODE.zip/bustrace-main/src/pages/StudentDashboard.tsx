import { useState } from 'react';
import { motion } from 'framer-motion';
import { MapPin, Bus, ArrowLeft, Share2, Wifi, WifiOff } from 'lucide-react';
import { Button } from '@/components/ui/button';
import MapView from '@/components/MapView';
import ConfirmationDialog from '@/components/ConfirmationDialog';
import { StudentLocation, ConfirmationRequest } from '@/types/tracking';

interface StudentDashboardProps {
  students: StudentLocation[];
  driverLocation: { lat: number; lng: number };
  confirmations: ConfirmationRequest[];
  sharingLocation: boolean;
  onToggleSharing: (sharing: boolean) => void;
  onRespondConfirmation: (id: string, present: boolean) => void;
  onBack: () => void;
}

export default function StudentDashboard({
  students,
  driverLocation,
  confirmations,
  sharingLocation,
  onToggleSharing,
  onRespondConfirmation,
  onBack,
}: StudentDashboardProps) {
  const activeConfirmation = confirmations.find(c => !c.responded) || null;
  const myStudent = students[0]; // In real app, would be the logged-in student

  return (
    <div className="h-screen bg-background flex flex-col overflow-hidden">
      {/* Header */}
      <header className="gradient-hero text-primary-foreground p-4 pb-6">
        <div className="flex items-center gap-3 mb-4">
          <button onClick={onBack} className="p-1.5 rounded-lg hover:bg-primary-foreground/10 transition-colors">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-xl font-bold flex-1">Student Dashboard</h1>
          <div className="flex items-center gap-2 text-sm">
            {sharingLocation ? (
              <Wifi className="w-4 h-4 text-secondary animate-pulse-soft" />
            ) : (
              <WifiOff className="w-4 h-4 opacity-50" />
            )}
          </div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex gap-3"
        >
          <div className="flex-1 bg-primary-foreground/10 rounded-lg p-3 backdrop-blur-sm">
            <div className="flex items-center gap-2 text-sm opacity-80 mb-1">
              <Bus className="w-4 h-4" />
              <span>Bus ETA</span>
            </div>
            <p className="text-2xl font-bold">~8 min</p>
          </div>
          <div className="flex-1 bg-primary-foreground/10 rounded-lg p-3 backdrop-blur-sm">
            <div className="flex items-center gap-2 text-sm opacity-80 mb-1">
              <MapPin className="w-4 h-4" />
              <span>Your Status</span>
            </div>
            <p className="text-lg font-bold capitalize">{myStudent?.status.replace('_', ' ') || 'Unknown'}</p>
          </div>
        </motion.div>
      </header>

      {/* Map */}
      <div className="flex-1 relative">
        <MapView
          students={myStudent ? [myStudent] : []}
          driverLocation={driverLocation}
          showDriver={true}
          className="h-full"
        />
      </div>

      {/* Bottom Actions */}
      <div className="p-4 bg-card border-t border-border">
        <Button
          className={`w-full h-12 text-base font-semibold ${
            sharingLocation
              ? 'bg-destructive hover:bg-destructive/90 text-destructive-foreground'
              : 'bg-success hover:bg-success/90 text-success-foreground'
          }`}
          onClick={() => onToggleSharing(!sharingLocation)}
        >
          <Share2 className="w-5 h-5 mr-2" />
          {sharingLocation ? 'Stop Sharing Location' : 'Share My Location'}
        </Button>
      </div>

      {/* Confirmation Dialog */}
      <ConfirmationDialog
        confirmation={activeConfirmation}
        onRespond={onRespondConfirmation}
      />
    </div>
  );
}
