import { motion } from 'framer-motion';
import { Bus, GraduationCap } from 'lucide-react';
import { UserRole } from '@/types/tracking';

interface RoleSelectionProps {
  onSelectRole: (role: UserRole) => void;
}

export default function RoleSelection({ onSelectRole }: RoleSelectionProps) {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-6 bg-background">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="text-center mb-12"
      >
        <div className="w-20 h-20 rounded-2xl gradient-hero flex items-center justify-center mx-auto mb-6 shadow-elevated">
          <Bus className="w-10 h-10 text-secondary" />
        </div>
        <h1 className="text-4xl font-bold text-foreground mb-3">BusTrack</h1>
        <p className="text-muted-foreground text-lg max-w-md">
          Real-time student pickup tracking for smarter, safer transportation
        </p>
      </motion.div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 w-full max-w-lg">
        <motion.button
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.2 }}
          whileHover={{ scale: 1.03 }}
          whileTap={{ scale: 0.98 }}
          onClick={() => onSelectRole('student')}
          className="group bg-card rounded-xl p-8 shadow-card border border-border hover:border-secondary hover:shadow-elevated transition-all text-left"
        >
          <div className="w-14 h-14 rounded-xl bg-secondary/15 flex items-center justify-center mb-5 group-hover:bg-secondary/25 transition-colors">
            <GraduationCap className="w-7 h-7 text-secondary" />
          </div>
          <h2 className="text-xl font-bold text-foreground mb-2">I'm a Student</h2>
          <p className="text-sm text-muted-foreground">
            Share your location and get notified when the bus is near
          </p>
        </motion.button>

        <motion.button
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.3 }}
          whileHover={{ scale: 1.03 }}
          whileTap={{ scale: 0.98 }}
          onClick={() => onSelectRole('driver')}
          className="group bg-card rounded-xl p-8 shadow-card border border-border hover:border-primary hover:shadow-elevated transition-all text-left"
        >
          <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center mb-5 group-hover:bg-primary/20 transition-colors">
            <Bus className="w-7 h-7 text-primary" />
          </div>
          <h2 className="text-xl font-bold text-foreground mb-2">I'm a Driver</h2>
          <p className="text-sm text-muted-foreground">
            View student locations and manage pickup confirmations
          </p>
        </motion.button>
      </div>
    </div>
  );
}
