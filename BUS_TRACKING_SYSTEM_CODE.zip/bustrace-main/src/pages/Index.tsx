import { useTrackingStore } from '@/store/trackingStore';
import RoleSelection from './RoleSelection';
import StudentDashboard from './StudentDashboard';
import DriverDashboard from './DriverDashboard';

const Index = () => {
  const store = useTrackingStore();

  if (!store.role) {
    return <RoleSelection onSelectRole={store.setRole} />;
  }

  if (store.role === 'student') {
    return (
      <StudentDashboard
        students={store.students}
        driverLocation={store.driverLocation}
        confirmations={store.confirmations}
        sharingLocation={store.sharingLocation}
        onToggleSharing={store.setSharingLocation}
        onRespondConfirmation={store.respondToConfirmation}
        onBack={() => store.setRole(null)}
      />
    );
  }

  return (
    <DriverDashboard
      students={store.students}
      driverLocation={store.driverLocation}
      onConfirmStudent={(id) => store.updateStudentStatus(id, 'confirmed')}
      onSkipStudent={(id) => store.updateStudentStatus(id, 'skipped')}
      onSendConfirmation={store.sendConfirmation}
      onBack={() => store.setRole(null)}
    />
  );
};

export default Index;
