import { useState } from 'react';
import { motion } from 'framer-motion';
import { ArrowLeft, Users, CheckCircle2, XCircle, Clock } from 'lucide-react';
import MapView from '@/components/MapView';
import StudentCard from '@/components/StudentCard';
import { StudentLocation } from '@/types/tracking';

interface DriverDashboardProps {
  students: StudentLocation[];
  driverLocation: { lat: number; lng: number };
  onConfirmStudent: (id: string) => void;
  onSkipStudent: (id: string) => void;
  onSendConfirmation: (id: string) => void;
  onBack: () => void;
}

export default function DriverDashboard({
  students,
  driverLocation,
  onConfirmStudent,
  onSkipStudent,
  onSendConfirmation,
  onBack,
}: DriverDashboardProps) {
  const [selectedTab, setSelectedTab] = useState<'all' | 'waiting' | 'confirmed'>('all');

  const counts = {
    all: students.length,
    waiting: students.filter(s => s.status === 'waiting').length,
    confirmed: students.filter(s => s.status === 'confirmed').length,
    skipped: students.filter(s => s.status === 'skipped').length,
  };

  const filtered = students.filter(s => {
    if (selectedTab === 'waiting') return s.status === 'waiting';
    if (selectedTab === 'confirmed') return s.status === 'confirmed';
    return true;
  });

  return (
    <div className="h-screen bg-background flex flex-col lg:flex-row overflow-hidden">
      {/* Map Section */}
      <div className="lg:flex-1 h-[40vh] lg:h-screen relative">
        <MapView
          students={students}
          driverLocation={driverLocation}
          showDriver={true}
          className="h-full"
        />
        <button
          onClick={onBack}
          className="absolute top-4 left-4 z-[500] bg-card shadow-elevated rounded-lg p-2.5 border border-border hover:bg-muted transition-colors"
        >
          <ArrowLeft className="w-5 h-5 text-foreground" />
        </button>
      </div>

      {/* Sidebar */}
      <div className="lg:w-[400px] flex flex-col border-l border-border bg-card">
        {/* Stats */}
        <div className="p-4 gradient-hero text-primary-foreground">
          <h1 className="text-xl font-bold mb-3">Driver Dashboard</h1>
          <div className="grid grid-cols-3 gap-2">
            <div className="bg-primary-foreground/10 rounded-lg p-2.5 text-center backdrop-blur-sm">
              <Users className="w-4 h-4 mx-auto mb-1 opacity-80" />
              <p className="text-lg font-bold">{counts.all}</p>
              <p className="text-[10px] opacity-70">Total</p>
            </div>
            <div className="bg-primary-foreground/10 rounded-lg p-2.5 text-center backdrop-blur-sm">
              <Clock className="w-4 h-4 mx-auto mb-1 text-secondary" />
              <p className="text-lg font-bold">{counts.waiting}</p>
              <p className="text-[10px] opacity-70">Waiting</p>
            </div>
            <div className="bg-primary-foreground/10 rounded-lg p-2.5 text-center backdrop-blur-sm">
              <CheckCircle2 className="w-4 h-4 mx-auto mb-1 text-success" />
              <p className="text-lg font-bold">{counts.confirmed}</p>
              <p className="text-[10px] opacity-70">Confirmed</p>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-border">
          {(['all', 'waiting', 'confirmed'] as const).map(tab => (
            <button
              key={tab}
              onClick={() => setSelectedTab(tab)}
              className={`flex-1 py-3 text-sm font-medium capitalize transition-colors ${
                selectedTab === tab
                  ? 'text-foreground border-b-2 border-secondary'
                  : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              {tab} ({counts[tab]})
            </button>
          ))}
        </div>

        {/* Student List */}
        <div className="flex-1 overflow-y-auto p-3 space-y-2">
          {filtered.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              <XCircle className="w-10 h-10 mx-auto mb-3 opacity-30" />
              <p>No students in this category</p>
            </div>
          ) : (
            filtered.map((student, i) => (
              <motion.div
                key={student.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
              >
                <StudentCard
                  student={student}
                  onConfirm={onConfirmStudent}
                  onSkip={onSkipStudent}
                  onSendConfirmation={onSendConfirmation}
                />
              </motion.div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
