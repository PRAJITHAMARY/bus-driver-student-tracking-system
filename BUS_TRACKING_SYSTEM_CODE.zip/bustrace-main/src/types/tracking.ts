export interface StudentLocation {
  id: string;
  name: string;
  lat: number;
  lng: number;
  status: 'waiting' | 'confirmed' | 'skipped' | 'picked_up';
  lastUpdated: Date;
  avatarColor: string;
}

export interface DriverLocation {
  lat: number;
  lng: number;
  heading: number;
}

export interface ConfirmationRequest {
  id: string;
  studentId: string;
  studentName: string;
  message: string;
  timestamp: Date;
  responded: boolean;
}

export type UserRole = 'student' | 'driver' | null;
