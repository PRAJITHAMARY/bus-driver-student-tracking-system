import { useEffect, useRef } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { StudentLocation } from '@/types/tracking';

// Fix leaflet default icon issue
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-shadow.png',
});

function createStudentIcon(color: string, status: string) {
  const statusEmoji = status === 'confirmed' ? '✅' : status === 'skipped' ? '❌' : status === 'picked_up' ? '🚌' : '⏳';
  return L.divIcon({
    className: 'custom-marker',
    html: `<div style="
      width: 36px; height: 36px; border-radius: 50%;
      background: ${color}; border: 3px solid white;
      box-shadow: 0 2px 8px rgba(0,0,0,0.3);
      display: flex; align-items: center; justify-content: center;
      font-size: 16px; color: white; font-weight: bold;
    ">${statusEmoji}</div>`,
    iconSize: [36, 36],
    iconAnchor: [18, 18],
  });
}

const busIcon = L.divIcon({
  className: 'custom-marker',
  html: `<div style="
    width: 44px; height: 44px; border-radius: 50%;
    background: hsl(45, 96%, 53%); border: 3px solid hsl(215, 50%, 17%);
    box-shadow: 0 4px 12px rgba(0,0,0,0.3);
    display: flex; align-items: center; justify-content: center;
    font-size: 22px;
  ">🚌</div>`,
  iconSize: [44, 44],
  iconAnchor: [22, 22],
});

interface MapViewProps {
  students: StudentLocation[];
  driverLocation: { lat: number; lng: number };
  showDriver?: boolean;
  onStudentClick?: (id: string) => void;
  className?: string;
}

export default function MapView({ students, driverLocation, showDriver = true, onStudentClick, className = '' }: MapViewProps) {
  const mapRef = useRef<L.Map | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const markersRef = useRef<L.LayerGroup | null>(null);

  // Initialize map
  useEffect(() => {
    if (!containerRef.current || mapRef.current) return;

    const map = L.map(containerRef.current).setView([driverLocation.lat, driverLocation.lng], 15);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
    }).addTo(map);

    markersRef.current = L.layerGroup().addTo(map);
    mapRef.current = map;

    return () => {
      map.remove();
      mapRef.current = null;
    };
  }, []);

  // Update markers
  useEffect(() => {
    if (!mapRef.current || !markersRef.current) return;

    markersRef.current.clearLayers();
    const points: L.LatLngExpression[] = [[driverLocation.lat, driverLocation.lng]];

    if (showDriver) {
      const busMarker = L.marker([driverLocation.lat, driverLocation.lng], { icon: busIcon });
      busMarker.bindPopup('<strong>Bus Location</strong><br />Currently en route');
      markersRef.current.addLayer(busMarker);
    }

    students.forEach(student => {
      const marker = L.marker([student.lat, student.lng], {
        icon: createStudentIcon(student.avatarColor, student.status),
      });
      marker.bindPopup(`<div class="text-sm"><strong>${student.name}</strong><br/>Status: <span style="text-transform:capitalize">${student.status.replace('_', ' ')}</span></div>`);
      if (onStudentClick) {
        marker.on('click', () => onStudentClick(student.id));
      }
      markersRef.current!.addLayer(marker);
      points.push([student.lat, student.lng]);
    });

    if (points.length > 1) {
      mapRef.current.fitBounds(L.latLngBounds(points), { padding: [50, 50] });
    }
  }, [students, driverLocation, showDriver, onStudentClick]);

  return (
    <div
      ref={containerRef}
      className={`rounded-lg overflow-hidden ${className}`}
      style={{ height: '100%', width: '100%', minHeight: '300px' }}
    />
  );
}
