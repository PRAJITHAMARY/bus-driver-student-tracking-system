import { StudentLocation } from '@/types/tracking';
import { Button } from '@/components/ui/button';
import { MapPin, Check, X, Send } from 'lucide-react';

interface StudentCardProps {
  student: StudentLocation;
  onConfirm?: (id: string) => void;
  onSkip?: (id: string) => void;
  onSendConfirmation?: (id: string) => void;
}

const statusConfig = {
  waiting: { label: 'Waiting', className: 'bg-warning/15 text-warning' },
  confirmed: { label: 'Confirmed', className: 'bg-success/15 text-success' },
  skipped: { label: 'Skipped', className: 'bg-destructive/15 text-destructive' },
  picked_up: { label: 'Picked Up', className: 'bg-primary/15 text-primary' },
};

export default function StudentCard({ student, onConfirm, onSkip, onSendConfirmation }: StudentCardProps) {
  const config = statusConfig[student.status];

  return (
    <div className="bg-card rounded-lg p-4 shadow-card border border-border animate-slide-up">
      <div className="flex items-center gap-3">
        <div
          className="w-10 h-10 rounded-full flex items-center justify-center text-sm font-bold"
          style={{ background: student.avatarColor, color: 'white' }}
        >
          {student.name.charAt(0)}
        </div>
        <div className="flex-1 min-w-0">
          <p className="font-semibold text-foreground truncate">{student.name}</p>
          <div className="flex items-center gap-1 text-xs text-muted-foreground">
            <MapPin className="w-3 h-3" />
            <span>Updated {Math.floor((Date.now() - student.lastUpdated.getTime()) / 60000)}m ago</span>
          </div>
        </div>
        <span className={`text-xs font-medium px-2.5 py-1 rounded-full ${config.className}`}>
          {config.label}
        </span>
      </div>

      {student.status === 'waiting' && (
        <div className="flex gap-2 mt-3">
          {onSendConfirmation && (
            <Button
              size="sm"
              variant="outline"
              className="flex-1 text-xs"
              onClick={() => onSendConfirmation(student.id)}
            >
              <Send className="w-3 h-3 mr-1" /> Ask Confirmation
            </Button>
          )}
          {onConfirm && (
            <Button
              size="sm"
              className="flex-1 text-xs bg-success hover:bg-success/90 text-success-foreground"
              onClick={() => onConfirm(student.id)}
            >
              <Check className="w-3 h-3 mr-1" /> Confirm
            </Button>
          )}
          {onSkip && (
            <Button
              size="sm"
              variant="outline"
              className="text-xs text-destructive border-destructive/30 hover:bg-destructive/10"
              onClick={() => onSkip(student.id)}
            >
              <X className="w-3 h-3" />
            </Button>
          )}
        </div>
      )}
    </div>
  );
}
