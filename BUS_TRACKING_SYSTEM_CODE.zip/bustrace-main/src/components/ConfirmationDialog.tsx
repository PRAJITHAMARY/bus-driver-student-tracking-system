import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ConfirmationRequest } from '@/types/tracking';
import { MapPin, CheckCircle2, XCircle } from 'lucide-react';

interface ConfirmationDialogProps {
  confirmation: ConfirmationRequest | null;
  onRespond: (id: string, present: boolean) => void;
}

export default function ConfirmationDialog({ confirmation, onRespond }: ConfirmationDialogProps) {
  return (
    <AnimatePresence>
      {confirmation && !confirmation.responded && (
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 50 }}
          className="fixed bottom-4 left-4 right-4 z-[1000] max-w-md mx-auto"
        >
          <div className="gradient-hero rounded-xl p-5 shadow-elevated text-primary-foreground">
            <div className="flex items-start gap-3 mb-4">
              <div className="w-10 h-10 rounded-full bg-secondary flex items-center justify-center animate-pulse-soft">
                <MapPin className="w-5 h-5 text-secondary-foreground" />
              </div>
              <div>
                <h3 className="font-bold text-lg">Pickup Confirmation</h3>
                <p className="text-sm opacity-90 mt-1">{confirmation.message}</p>
              </div>
            </div>
            <div className="flex gap-3">
              <Button
                className="flex-1 bg-success hover:bg-success/90 text-success-foreground"
                onClick={() => onRespond(confirmation.id, true)}
              >
                <CheckCircle2 className="w-4 h-4 mr-2" />
                Yes, I'm here
              </Button>
              <Button
                variant="outline"
                className="flex-1 border-primary-foreground/30 text-primary-foreground hover:bg-primary-foreground/10"
                onClick={() => onRespond(confirmation.id, false)}
              >
                <XCircle className="w-4 h-4 mr-2" />
                Not today
              </Button>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
