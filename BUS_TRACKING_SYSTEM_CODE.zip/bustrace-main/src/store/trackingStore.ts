import { useState, useCallback } from 'react';
import { StudentLocation, ConfirmationRequest, UserRole } from '@/types/tracking';

const AVATAR_COLORS = [
  'hsl(215, 50%, 17%)',
  'hsl(45, 96%, 53%)',
  'hsl(142, 70%, 45%)',
  'hsl(0, 84%, 60%)',
  'hsl(280, 60%, 50%)',
  'hsl(190, 80%, 45%)',
];

// Mock students for demo
const MOCK_STUDENTS: StudentLocation[] = [
  { id: '1', name: 'Aisha Khan', lat: 12.9716, lng: 77.5946, status: 'waiting', lastUpdated: new Date(), avatarColor: AVATAR_COLORS[0] },
  { id: '2', name: 'Rahul Sharma', lat: 12.9756, lng: 77.5906, status: 'waiting', lastUpdated: new Date(), avatarColor: AVATAR_COLORS[1] },
  { id: '3', name: 'Priya Patel', lat: 12.9686, lng: 77.5986, status: 'confirmed', lastUpdated: new Date(), avatarColor: AVATAR_COLORS[2] },
  { id: '4', name: 'Dev Mehta', lat: 12.9736, lng: 77.5926, status: 'waiting', lastUpdated: new Date(), avatarColor: AVATAR_COLORS[3] },
  { id: '5', name: 'Sara Ahmed', lat: 12.9696, lng: 77.5966, status: 'skipped', lastUpdated: new Date(), avatarColor: AVATAR_COLORS[4] },
];

export function useTrackingStore() {
  const [role, setRole] = useState<UserRole>(null);
  const [students, setStudents] = useState<StudentLocation[]>(MOCK_STUDENTS);
  const [confirmations, setConfirmations] = useState<ConfirmationRequest[]>([]);
  const [sharingLocation, setSharingLocation] = useState(false);
  const [driverLocation] = useState({ lat: 12.9726, lng: 77.5946, heading: 45 });

  const updateStudentStatus = useCallback((id: string, status: StudentLocation['status']) => {
    setStudents(prev => prev.map(s => s.id === id ? { ...s, status } : s));
  }, []);

  const sendConfirmation = useCallback((studentId: string) => {
    const student = students.find(s => s.id === studentId);
    if (!student) return;
    const req: ConfirmationRequest = {
      id: crypto.randomUUID(),
      studentId,
      studentName: student.name,
      message: `Are you at the pickup point? The bus is approaching.`,
      timestamp: new Date(),
      responded: false,
    };
    setConfirmations(prev => [...prev, req]);
  }, [students]);

  const respondToConfirmation = useCallback((confirmId: string, present: boolean) => {
    setConfirmations(prev =>
      prev.map(c => c.id === confirmId ? { ...c, responded: true } : c)
    );
    const conf = confirmations.find(c => c.id === confirmId);
    if (conf) {
      updateStudentStatus(conf.studentId, present ? 'confirmed' : 'skipped');
    }
  }, [confirmations, updateStudentStatus]);

  return {
    role, setRole,
    students, setStudents,
    confirmations, sendConfirmation, respondToConfirmation,
    sharingLocation, setSharingLocation,
    driverLocation,
    updateStudentStatus,
  };
}
